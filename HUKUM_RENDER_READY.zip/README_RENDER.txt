HUKUM DASHBOARD — Render deployment package

DEPLOY:
1. Extract this ZIP.
2. Upload the extracted project to a new GitHub repository.
3. In Render, choose New + -> Blueprint (or New + -> Web Service).
4. For Blueprint, select this repository; Render reads render.yaml.
   For manual Web Service:
   - Runtime: Python
   - Build command: pip install -r requirements.txt
   - Start command: gunicorn app:app --workers 1 --threads 4 --bind 0.0.0.0:$PORT --timeout 120
5. In Render Environment settings, set:
   USER_PASSWORD = choose a strong password
   ADMIN_PASSWORD = choose a different strong password
   FLASK_SECRET_KEY = a long random secret (if not auto-generated)
6. Deploy and open the Render URL ending in onrender.com.

LOGIN DEFAULT USERNAMES:
USER: DINESH
ADMIN: HUKUM
Set both passwords yourself in Render Environment settings before sharing the site.

IMPORTANT:
- This package contains the existing HUKUM web dashboard (login, upload, browser audio player/effects, and server-side bot-token settings UI).
- The token settings page stores an official Discord BOT token server-side only. It does not implement self-bot automation or VC auto-joining.
- Never enter a personal Discord account token. Use only an official bot token.
- Render free web services may sleep when idle and local files may be ephemeral. Uploaded audio and token files saved on the local filesystem may not persist across redeploys/restarts. For persistent storage, configure a suitable persistent disk or external storage, and keep secrets in Render Environment settings.
- Do not commit passwords, tokens, or .env files to GitHub.
