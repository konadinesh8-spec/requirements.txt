import os
import secrets
from functools import wraps
from urllib.parse import urlparse

from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = os.path.join(app.root_path, "uploads")
app.config["TOKEN_FOLDER"] = os.path.join(app.root_path, "instance")
app.config["TOKEN_FILE"] = os.path.join(app.config["TOKEN_FOLDER"], "discord_bot_token.txt")

ALLOWED_EXTENSIONS = {"mp3", "wav", "ogg", "m4a", "aac", "flac"}

# Set these in Replit Secrets. These are demo credentials; change them before public deployment.
ACCOUNTS = {
    "USER": {
        "username": os.environ.get("USER_USERNAME", "DINESH"),
        "password": os.environ.get("USER_PASSWORD", "DINESH"),
        "role": "USER",
    },
    "ADMIN": {
        "username": os.environ.get("ADMIN_USERNAME", "HUKUM"),
        "password": os.environ.get("ADMIN_PASSWORD", "HUKM 163"),
        "role": "ADMIN",
    },
}

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "role" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if session.get("role") != "ADMIN":
            flash("Admin access required for Discord token settings.", "error")
            return redirect(url_for("dashboard"))
        return fn(*args, **kwargs)
    return wrapper

def discord_token_is_saved():
    return os.path.isfile(app.config["TOKEN_FILE"])

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        selected_role = request.form.get("role", "").upper()
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        account = ACCOUNTS.get(selected_role)
        if account and secrets.compare_digest(username, account["username"]) and secrets.compare_digest(password, account["password"]):
            session.clear()
            session["username"] = account["username"]
            session["role"] = account["role"]
            return redirect(url_for("dashboard"))
        flash("Invalid role, username, or password.", "error")
    if "role" in session:
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", username=session["username"], role=session["role"],
                           token_configured=discord_token_is_saved())

@app.route("/discord-token", methods=["POST"])
@admin_required
def discord_token():
    action = request.form.get("action", "")
    if action == "save":
        token = request.form.get("bot_token", "").strip()
        if len(token) < 20 or any(ch.isspace() for ch in token):
            flash("Enter a valid Discord bot token. The token was not saved.", "error")
            return redirect(url_for("dashboard") + "#discord")
        os.makedirs(app.config["TOKEN_FOLDER"], exist_ok=True)
        fd = os.open(app.config["TOKEN_FILE"], os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(token)
        try:
            os.chmod(app.config["TOKEN_FILE"], 0o600)
        except OSError:
            pass
        flash("Discord bot token saved securely on the server.", "success")
    elif action == "remove":
        try:
            os.remove(app.config["TOKEN_FILE"])
            flash("Saved Discord bot token removed.", "success")
        except FileNotFoundError:
            flash("No saved dashboard token was found.", "error")
    else:
        flash("Unknown token action.", "error")
    return redirect(url_for("dashboard") + "#discord")

@app.route("/upload", methods=["POST"])
@login_required
def upload():
    file = request.files.get("audio_file")
    if not file or not file.filename:
        flash("Choose an audio file first.", "error")
        return redirect(url_for("dashboard"))
    filename = secure_filename(file.filename)
    if not allowed_file(filename):
        flash("Allowed formats: MP3, WAV, OGG, M4A, AAC, FLAC.", "error")
        return redirect(url_for("dashboard"))
    # Random prefix avoids filename collisions.
    safe_name = secrets.token_hex(8) + "_" + filename
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], safe_name))
    return redirect(url_for("play_upload", filename=safe_name))

@app.route("/uploads/<path:filename>")
@login_required
def play_upload(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename, as_attachment=False)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.errorhandler(413)
def too_large(_error):
    flash("File too large. Maximum upload size is 25 MB.", "error")
    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "3000"))
    app.run(host="0.0.0.0", port=port, debug=False)